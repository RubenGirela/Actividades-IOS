<?php

class ControladorProfesor{
    
    private $rest,$get,$objeto;
    
    function __construct($rest,$get,$objeto){
        $this->objeto=$objeto;
        $this->rest=$rest;
        $this->get=$get;
    }
    
    function delete(){
        echo 'borrar';
    }
    
    function get(){
        echo 'get';
    }
    
    function post(){
        $p = new profesor();
        $p->setNombre($this->objeto->nombre);
        var_dump($p);
        $modelo= new Modelo();
        $id = $modelo->insertProfesor($p);
        return $id;
    }
    
    function put(){
        echo 'put';
    }
}