<?php

class Modelo{
    
    private $gestor;
    
    function __construct(){
        $bs = new Bootstrap();
        $this->gestor = $bs->getEntityManager();
    }
    
    function insertProfesor(profesor $objeto){
        
        $this->gestor->persist($objeto);
        $this->gestor->flush();
        return $objeto->getId();
    }
    
    function deleteProfesor($id){
        
    }
    
    function updateProfesor(profesor $objeto){
        
    }
    
    function getProfesor($id){
        
    }
    
    function setProfesor(){
        
    }
}