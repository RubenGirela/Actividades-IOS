<?php

    require_once('../ac/AutoCarga.php');
    require_once('../ac/vendor/autoload.php');
    
    $json = json_decode(file_get_contents('php://input'));
     header('Content-Type: application/json');
       
    //le llegaran todas las peticiónes
    $metodo = $_SERVER['REQUEST_METHOD'];
    
    $parametros=explode("/", $_SERVER['REQUEST_URI']);
    
    $fichero = 'verificar.txt';
    file_put_contents($fichero, 'metodo: ' . $metodo . ' , json: ' . json_encode($json) . ' , parametros: ' . $_SERVER['REQUEST_URI'] . "\n", FILE_APPEND | LOCK_EX);
    //echo '{"r" : 1}';
    //exit;
    $api = new Api($metodo,$json,$parametros,$_GET);
    
    $api -> peticiones();
    
    echo $api -> getResponse();
    
    /*********************************************************************************************************************/
    
    //$_GET, $_POST, $_REQUEST, (php://input) -> payload en crudo
    
    
    /*$bootstrap = new Bootstrap();
    $gestor = $bootstrap->getEntityManager();
    
    $dominio= $_SERVER['HTTP_HOST'];;
    $urlPath = $_SERVER['REQUEST_URI'];
    
    $pos= strrpos($urlPath,'/');
    $ruta = substr($urlPath,$pos+1);
    
    $n=0;
    
    echo '<br>PATH DESGLOSADO <br>';
    foreach ($parametros as $value) {
        echo 'Parametro '.$n.': '.$value.'</br>';
        $n++;
    }
    echo "<br>METODO: $metodo";
    echo "<br> JSON: $json";
    echo "<br> RUTA: $ruta";
    echo "<br> DOMINIO: ".$dominio;
    echo "<br> PATH: $urlPath";*/
    
    /*switch($metodo){
        
        case 'PUT':
                echo '<h1>MODIFICAR</h1>';
            break;
        case 'DELETE':
                $dql = 'delete FROM actividad where id = :actividad';
                //$query = $gestor->createQuery($dql);
                $query = $gestor->createQuery($dql)->setParameter('actividad', $objeto->actividad);
                $borrrar_actividades = $query->getResult();
            break;
        default:
            echo "Error 404 no se ha encontrado el metodo";
            break;
    }*/
    
    exit();