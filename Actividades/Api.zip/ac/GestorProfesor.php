<?php

class GestorProfesor{
    
    private $rest,$get;
    
    function __construct($rest,$get){
        
        $this->rest=$rest;
        $this->get=$get;
    }
    
    function delete(){
        echo 'borrar';
    }
    
    function get(){
        echo 'get';
    }
    
    function post(){
        echo 'post';
    }
    
    function put(){
        echo 'put';
    }
}