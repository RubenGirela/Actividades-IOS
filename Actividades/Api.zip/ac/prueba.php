<?php

    require_once('../ac/Autoload.php');

    $bootstrap = new Bootstrap();
    $gestor = $bootstrap->getEntityManager();
    
    /*$dql = 'select r FROM profesor r where r.nombre = :nombre or r.id = :id or r.departamento = :depart order by r.id desc';
    $query = $gestor->createQuery($dql)
                    ->setParameter('nombre', 'nombre')
                    ->setParameter('depart','departamento')
                    ->setParameter('id', '3');
    $profesor = $query->getResult();
    foreach ($profesor as $profe) {
        echo $profe->getNombre() . '<br>';
    }
    exit();*/
    
    $dql = 'select r FROM actividad r where r.id_profesor = :profesor order by r.id desc';
    $query = $gestor->createQuery($dql)
                    ->setParameter('profesor', '3');
    $actividades = $query->getResult();
    foreach ($actividades as $actividad) {
        echo $actividad->getDescripcionCorta() . '<br>';
    }
    //exit();
    
    /*try {// insertar profesor
        $actividades = new profesor();
        $actividades->setNombre('nombre3');
        $actividades->setDepartamento('departamento');
        $gestor->persist($actividades);// insercion
        echo '<h1>'.$actividades->getId() . '</h1><br>';
        $gestor->flush();// comint
        echo $actividades->getId();
    } catch(Exception $e){
        echo "<h1>Error </h1>";
    }*/
    
    /*try {//insertar actividad
        $actividades = new actividad();
        $actividades->setIdProfesor('3');
        $actividades->setDescripcionLarga(utf8_decode('descripción larga2'));
        $actividades->setDescripcionCorta(utf8_decode('Descripción corta2'));
        $actividades->setTitulo(utf8_decode('Titulo'));
        $actividades->setGrupo(utf8_decode('grupo'));
        $fecha=new DateTime('2012-12-12');
        $actividades->setFecha($fecha);
        $actividades->setLugar(utf8_decode('Lugar'));
        $horaI=new DateTime('12:12');
        $horaF=new DateTime('13:12');
        $actividades->setHoraInicial($horaI);
        $actividades->setHoraFinal($horaF);
        $actividades->setFoto('foto');
        $gestor->persist($actividades);// insercion
        echo '<h1>'.$actividades->getId() . '</h1><br>';
        $gestor->flush();// comint
        echo $actividades->getId();
    } catch(Exception $e){
        echo "<h1>Error </h1>";
    }*/
exit();