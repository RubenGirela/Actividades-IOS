<?php

class Modificar{
    
    function mod($rest,$gestor,$objeto){
        
        //JSON
        /*
            {
                "id" : 2, 
                "nombre" : "pepe", 
                "departamento" : "titulo1"
            }
        */
    
        if($rest=='profesor'){
            
            if($objeto->id!='' && $objeto->nombre!='' && $objeto->departamento!=''){
                
                $profesor = $gestor->getRepository('Profesor')->findOneBy(array('id' => $objeto->id));
                
                $nombre=$objeto->nombre;
                $departamento=$objeto->departamento;
                
                $aux=false;
                
                if($profesor!=null){
                    
                    $profesorn = $gestor->getRepository('Profesor')->findOneBy(array('nombre' => $nombre));
                    $profesord = $gestor->getRepository('Profesor')->findOneBy(array('departamento' => $departamento));
                    
                    if($profesorn === null){
                        $profesor->setNombre($nombre); 
                        $aux==true;
                    }
                    if($profesord===null){
                        $profesor->setDepartamento($departamento);
                        $aux=true;
                    }
                    
                    if($aux){
                        
                        //echo '<h4>Se ha modificado correctamente el profesor '.$profesor->getNombre().'</h4>';
                        
                        $gestor->persist($profesor);
                        $gestor->flush();
                    }else{
                        
                        //echo '<h4>Error de modificacion del profesor</h4>';
                    }
                    
                }else{
                    
                    //echo '<h4>Error ese profesor no existe creelo o pongase en contacto con el desarrollador</h4>';
                }
            }else{
                
                //echo '<h4>Error los campos estan vacios</h4>';
            }
        }elseif($rest=='actividad'){
            
            //JSON
            /*
                {
                    "id" : 2, 
                    "profesor" : 1, 
                    "titulo" : "titulo1", 
                    "descripcion_corta" : "descripción corta 1", 
                    "descripcion_larga" : "descripción larga 1", 
                    "grupo" : "grupo1", 
                    "fecha" : "fecha1", 
                    "lugar" : "lugar1", 
                    "hora_inicial" : "12:00", 
                    "hora_final" : "13:00"
                    
                }
            */
            echo $objeto->id;
            if($objeto->id!='' && $objeto->titulo!='' && $objeto->profesor!='' && $objeto->grupo!='' && $objeto->fecha!='' && $objeto->lugar!='' && $objeto->hora_inicial!='' && $objeto->hora_final!=''){
                
                //DATOS
                $id_ac=$objeto->id;
                $profesor_ac=$objeto->profesor;
                $titulo=$objeto->titulo;
                $grupo=$objeto->grupo;
                $descripcionL=$objeto->descripcion_larga;
                $descripcionC=$objeto->descripcion_corta;
                $fecha=new DateTime($objeto->fecha);                    
                $lugar=$objeto->lugar;
                $hora_inicial=new DateTime($objeto->hora_inicial);
                $hora_final=new DateTime($objeto->hora_final);
                
                //Busca si existe esa actividad
                $actividad = $gestor->getRepository('Actividad')->findOneBy(array('id' => $id_ac));
                
                if($actividad!=null){
                    
                    
                        $actividad->setTitulo($titulo);
                        $actividad->setGrupo($grupo);
                        $actividad->setDescripcionCorta($descripcionC);
                        $actividad->setDescripcionLarga($descripcionL);
                        $actividad->setFecha($fecha);
                        $actividad->setLugar($lugar);
                        $actividad->setHoraInicial($hora_inicial);
                        $actividad->setHoraFinal($hora_final);
                        
                        $gestor->persist($actividad);
                        $gestor->flush();
                        
                        //echo '<h4>Se ha modificado correctamente la actividad '.$titulo.'</h4>';
                    
                }else{
                    
                    //echo '<h4>Error esa actividad no existe creelo o pongase en contacto con el desarrollador</h4>';
                }
            }else{
                
                //echo '<h4>Error los campos estan vacios</h4>';
            }
        }
    }
}