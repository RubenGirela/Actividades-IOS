<?php

class Borrar{
    
    function borrado($rest,$gestor,$objeto){
        
        //JSON EN AMBOS
            /*
                {
                    "id" : 2
                }
            */
        
        if($rest=='profesor'){
            if($objeto->id!=''){
                
                $profesor = $gestor->getRepository('Profesor')->findOneBy(array('id' => $objeto->id));
                
                if($profesor!=null){
                    
                    //print_r('Se ha eliminado correctamente el profesor '.$profesor->getNombre());
                    $gestor->remove($profesor);
                    $gestor->flush();
                    
                }else{
                    print_r('Error ese profesor no existe creelo o pongase en contacto con el desarrollador');
                }
            }else{
                print_r('Error los campos estan vacios, pongase en contacto con el tecnico');
            }
        }elseif($rest=='actividad'){
            
            if($objeto->id!=''){
                
                $actividad = $gestor->getRepository('Actividad')->findOneBy(array('id' => $objeto->id));
                
                if($actividad!=null){
                    
                    //echo '<h4>Se ha eliminado correctamente la actividad '.$actividad->getTitulo().'</h4>';
                    $gestor->remove($actividad);
                    $gestor->flush();
                    
                }else{
                    print_r('Error esa actividad no existe creelo o pongase en contacto con el desarrollador');
                }
            }else{
                print_r('Error los campos estan vacios');
            }
        }
    }
}