<?php
class Mostrar{
    
    function see($rest,$gestor,$rest2){
        
        if($rest=='actividades'){
            
            //NOTA getProfesor() Y id_profesor ES UN OBJETO CON TODOS LOS DATOS DEL PROFESOR (NO EL ID DEL PROFESOR)
            $repositorioRegistros = $gestor->getRepository('Actividad');
            $result = $repositorioRegistros->findAll();
            
            //OTRA FORMA PERO NO LA VOY A USAR
            /*$dql = 'select a, p2 FROM actividad a JOIN a.id_profesor p2 order by a.id desc';
            $query = $gestor->createQuery($dql);
            $result = $query->getResult();*/
           /* echo '<style>table, td, th, tr{border:1px solid black; border-collapse:collapse;} td{padding:0.5rem;}</style>';
            echo '<table>';*/
            $aux=0;
            $arrayActividades=array();
            
            foreach ($result as $r){
                $f = $r->getFecha();
               
               //esto funciona por arte de magia por que no puedo acceder al objeto asi que lo convierto en un array
               $f = json_decode(json_encode($f));
               //echo $f->date;
               //convierte a milisegundos
                $fechaDate= strtotime($f->date);
                
                //convierte a string en el formato dia/mes/año
                $fecha = date('d/m/Y', $fechaDate);
                //echo $fecha;
                
                $hi = json_decode(json_encode($r->getHorainicial()));
                $hf = json_decode(json_encode($r->getHorafinal()));
                //milisegundos
                $hi3=strtotime($hi->date);
                $hf3=strtotime($hf->date);
                //formato 24:59
                $hi2 = date('H:i', $hi3);
                $hf2 = date('H:i', $hf3); 
                if(strlen($r->getDescripcionLarga())>200){
                    $descripcionL=substr($r->getDescripcionLarga(),0,200);
                }else{
                    $descripcionL=$r->getDescripcionLarga();
                }
                //echo $descripcionL."<br>";
                

                
                /*echo $r->getProfesor()->getId().'<br>';
                echo '<br>';*/
               
                if($r->getTitulo()!="" && $r->getDescripcionCorta()!="" && $r->getDescripcionLarga()!="" && $r->getGrupo()!="" && $r->getLugar()!="" && $fecha!="" && $hi2!="" && $hf2!=""){
                    $arrayActividades[$aux] = [
                        "id" => $r->getId(),
                        "titulo" => utf8_encode($r->getTitulo()), 
                        "descripcionC" => utf8_encode($r->getDescripcionCorta()),
                        "descripcionL" => utf8_encode($descripcionL),
                        "grupo" => utf8_encode($r->getGrupo()),
                        "fecha" => $fecha,
                        "lugar" => utf8_encode($r->getLugar()),
                        "hi" => $hi2,
                        "hf" => $hf2,
                        "profesor" => $r->getProfesor()->getId(),
                        "foto" => $r->getFoto()
                    ];
                    
                }

                /*echo '<tr><th colspan="2">Actividad'.$aux.'</th></tr>';
                echo '<tr><td>Profesor</td><td>' . $r->getProfesor()->getNombre() . '</td></tr>';
                echo '<tr><td>Actividad</td><td>' . $r->getTitulo() . '</td></tr>';
                echo '<tr><td>'.utf8_decode(Descripción).'</td><td>' . $r->getDescripcionLarga() . '</td></tr>';
                echo '<tr><td>Grupo</td><td>' . $r->getGrupo() . '</td></tr>';*/
                $aux++;
            }
            
            foreach ($arrayActividades as $clave => $fila){
                $claves[$clave] = $fila['fecha'];
            }
            //Ordenamos el array por el contenido, que es el campo que hemos elegido.
            arsort($claves);
            //print_r($claves);
            //recorremos el array de claves ya ordenado y vamos rellenando un nuevo array
            //con los campos completos con el nuevo orden
            //Recorremos el array de claves ordenadas y rellenamos de nuevo nuestro array
            $aux=0;
            foreach ($claves as $clave => $fila){
              $arrayActividades2[$aux] = $arrayActividades[$clave];
              $aux++;
            }
            
            $arrayActividades=["actividades" => $arrayActividades2];
            
            $jsonActividades = json_encode($arrayActividades);
            //echo $jsonActividades;
            //return $jsonActividades;
            print_r($jsonActividades);
            
            //echo '</table>';
        }elseif ($rest=='profesores') {
            
            //NOTA getProfesor() Y id_profesor ES UN OBJETO CON TODOS LOS DATOS DEL PROFESOR (NO EL ID DEL PROFESOR)
            $repositorioRegistros = $gestor->getRepository('Profesor');
            $result = $repositorioRegistros->findAll();
            
            //OTRA FORMA PERO NO LA VOY A USAR
            /*$dql = 'select a, p2 FROM actividad a JOIN a.id_profesor p2 order by a.id desc';
            $query = $gestor->createQuery($dql);
            $result = $query->getResult();*/
            
            /*echo '<style>table, td, th, tr{border:1px solid black; border-collapse:collapse;} td{padding:0.5rem;}</style>';
            echo '<table>';
            $aux=1;*/
            $aux=0;
            
            $arrayProfesores=array();
            
            foreach ($result as $r){
                
                $arrayProfesores[$aux] = ["id" => $r->getId(),"nombre" => $r->getNombre()];
                $aux++;
                /*echo '<tr><th colspan="2">Profesor'.$aux.'</th></tr>';
                echo '<tr><td>Profesor</td><td>' . $r->getNombre() . '</td></tr>';
                echo '<tr><td>Departamento</td><td>' . $r->getDepartamento() . '</td></tr>';
                $aux++;*/
            }
            /*foreach ($arrayProfesores as $r){
                foreach($r as $r2 => $v){
                    echo $r2."<br>";
                }
            }*/
            $arrayProfesores=["profesores" => $arrayProfesores];
            $jsonprofesores = json_encode($arrayProfesores);
            echo $jsonprofesores;
            return $jsonprofesores;
            //echo '</table>';
        }elseif($rest=='actividad'){
            
            $aux=0;
            
            if($rest2!=''){
                $patron = '/^[0-9]{2}-[0-9]{2}-[0-9]{4}$/';
                $r=preg_match($patron, $rest2);
                
                $patron = '/^[0-9]+$/';
                $r2=preg_match($patron, $rest2);

                if($r>0){// filtra por fecha ac/actividad/12-03-2017
                    $fecha=new DateTime($rest2);
                    
                    //$fecha3 = date('d/m/Y', strtotime($rest2));
                    
                    $actividadBus = $gestor->getRepository('Actividad');
                    $result = $actividadBus->findAll();

                    //echo '<style>table, td, th, tr{border:1px solid black; border-collapse:collapse;} td{padding:0.5rem;}</style>';
                    //echo '<table>';
                    
                    foreach ($result as $r){
                        
                        if($r->getFecha()==$fecha){
                            
                            //print_r($r->getFecha());
                            
                            $f = $r->getFecha();
                           
                           //esto funciona por arte de magia por que no puedo acceder al objeto asi que lo convierto en un array
                           $f = json_decode(json_encode($f));
                           //echo $f->date;
                           //convierte a milisegundos
                            $fechaDate= strtotime($f->date);
                            
                            //convierte a string en el formato dia/mes/año
                            $fecha2 = date('d/m/Y', $fechaDate);
                            //echo $fecha;
                            
                            $hi = json_decode(json_encode($r->getHorainicial()));
                            $hf = json_decode(json_encode($r->getHorafinal()));
                            //milisegundos
                            $hi3=strtotime($hi->date);
                            $hf3=strtotime($hf->date);
                            //formato 24:59
                            $hi2 = date('H:i', $hi3);
                            $hf2 = date('H:i', $hf3); 
                            if(strlen($r->getDescripcionLarga())>200){
                                $descripcionL=substr($r->getDescripcionLarga(),0,200);
                            }else{
                                $descripcionL=$r->getDescripcionLarga();
                            }
                            //echo $descripcionL."<br>";
                            
            
                            
                            /*echo $r->getProfesor()->getId().'<br>';
                            echo '<br>';*/
                           
                            if($r->getTitulo()!="" && $r->getDescripcionCorta()!="" && $r->getDescripcionLarga()!="" && $r->getGrupo()!="" && $r->getLugar()!="" && $fecha!="" && $hi2!="" && $hf2!=""){
                                $arrayActividades[$aux] = [
                                    "id" => $r->getId(),
                                    "titulo" => utf8_encode($r->getTitulo()), 
                                    "descripcionC" => utf8_encode($r->getDescripcionCorta()),
                                    "descripcionL" => utf8_encode($descripcionL),
                                    "grupo" => utf8_encode($r->getGrupo()),
                                    "fecha" => $fecha2,
                                    "lugar" => utf8_encode($r->getLugar()),
                                    "hi" => $hi2,
                                    "hf" => $hf2,
                                    "profesor" => $r->getProfesor()->getId(),
                                    "foto" => $r->getFoto()
                                ];
                            }
            
                            /*echo '<tr><th colspan="2">Actividad'.$aux.'</th></tr>';
                            echo '<tr><td>Profesor</td><td>' . $r->getProfesor()->getNombre() . '</td></tr>';
                            echo '<tr><td>Actividad</td><td>' . $r->getTitulo() . '</td></tr>';
                            echo '<tr><td>'.utf8_decode(Descripción).'</td><td>' . $r->getDescripcionLarga() . '</td></tr>';
                            echo '<tr><td>Grupo</td><td>' . $r->getGrupo() . '</td></tr>';*/
                            $aux++;
                        }
                    }
                    
                    foreach ($arrayActividades as $clave => $fila){
                        $claves[$clave] = $fila['fecha'];
                    }
                    //Ordenamos el array por el contenido, que es el campo que hemos elegido.
                    arsort($claves);
                    //print_r($claves);
                    //recorremos el array de claves ya ordenado y vamos rellenando un nuevo array
                    //con los campos completos con el nuevo orden
                    //Recorremos el array de claves ordenadas y rellenamos de nuevo nuestro array
                    $aux=0;
                    foreach ($claves as $clave => $fila){
                      $arrayActividades2[$aux] = $arrayActividades[$clave];
                      $aux++;
                    }
                    
                    $arrayActividades=["actividades" => $arrayActividades2];
                    
                    $jsonActividades = json_encode($arrayActividades);
                    //echo $jsonActividades;
                    //return $jsonActividades;
                    print_r($jsonActividades);
                    
                }elseif($r2>0){//filtra por profesor ac/actividad/1
                    
                    $actividadBus = $gestor->getRepository('Actividad');
                    $result = $actividadBus->findAll();

                    //echo '<style>table, td, th, tr{border:1px solid black; border-collapse:collapse;} td{padding:0.5rem;}</style>';
                    //echo '<table>';
                            
                    foreach ($result as $r){
                        
                        if($r->getProfesor()->getId()==$rest2){
                            $f = $r->getFecha();
                           
                           //esto funciona por arte de magia por que no puedo acceder al objeto asi que lo convierto en un array
                           $f = json_decode(json_encode($f));
                           //echo $f->date;
                           //convierte a milisegundos
                            $fechaDate= strtotime($f->date);
                            
                            //convierte a string en el formato dia/mes/año
                            $fecha = date('d/m/Y', $fechaDate);
                            //echo $fecha;
                            
                            $hi = json_decode(json_encode($r->getHorainicial()));
                            $hf = json_decode(json_encode($r->getHorafinal()));
                            //milisegundos
                            $hi3=strtotime($hi->date);
                            $hf3=strtotime($hf->date);
                            //formato 24:59
                            $hi2 = date('H:i', $hi3);
                            $hf2 = date('H:i', $hf3); 
                            if(strlen($r->getDescripcionLarga())>200){
                                $descripcionL=substr($r->getDescripcionLarga(),0,200);
                            }else{
                                $descripcionL=$r->getDescripcionLarga();
                            }
                           
                            if($r->getTitulo()!="" && $r->getDescripcionCorta()!="" && $r->getDescripcionLarga()!="" && $r->getGrupo()!="" && $r->getLugar()!="" && $fecha!="" && $hi2!="" && $hf2!=""){
                                $arrayActividades[$aux] = [
                                    "id" => $r->getId(),
                                    "titulo" => utf8_encode($r->getTitulo()), 
                                    "descripcionC" => utf8_encode($r->getDescripcionCorta()),
                                    "descripcionL" => utf8_encode($descripcionL),
                                    "grupo" => utf8_encode($r->getGrupo()),
                                    "fecha" => $fecha,
                                    "lugar" => utf8_encode($r->getLugar()),
                                    "hi" => $hi2,
                                    "hf" => $hf2,
                                    "profesor" => $r->getProfesor()->getId(),
                                    "foto" => $r->getFoto()
                                ];
                            }
                            $aux++;
                        }    
                    }
                    
                    foreach ($arrayActividades as $clave => $fila){
                        $claves[$clave] = $fila['fecha'];
                    }
                    //Ordenamos el array por el contenido, que es el campo que hemos elegido.
                    arsort($claves);
                    //print_r($claves);
                    //recorremos el array de claves ya ordenado y vamos rellenando un nuevo array
                    //con los campos completos con el nuevo orden
                    //Recorremos el array de claves ordenadas y rellenamos de nuevo nuestro array
                    $aux=0;
                    foreach ($claves as $clave => $fila){
                      $arrayActividades2[$aux] = $arrayActividades[$clave];
                      $aux++;
                    }
                    
                    $arrayActividades=["actividades" => $arrayActividades2];
                    
                    $jsonActividades = json_encode($arrayActividades);
                    //echo $jsonActividades;
                    //return $jsonActividades;
                    print_r($jsonActividades);
                    
                }
                
            }
            
        }elseif($rest=='profesor'){
            
            if($rest2!='' && $rest2>0){
            
                //NOTA getProfesor() Y id_profesor ES UN OBJETO CON TODOS LOS DATOS DEL PROFESOR (NO EL ID DEL PROFESOR)
                $profesorBuscado = $gestor->getRepository('Profesor')->findOneBy(array('id' => $rest2));

                if($profesorBuscado!=''){
                    /*echo '<style>table, td, th, tr{border:1px solid black; border-collapse:collapse;} td{padding:0.5rem;}</style>';
                    echo '<table>';
                    
                    echo '<tr><th colspan="2">Profesor</th></tr>';
                    echo '<tr><td>Profesor</td><td>' . $profesorBuscado->getNombre() . '</td></tr>';
                    echo '<tr><td>Departamento</td><td>' . $profesorBuscado->getDepartamento() . '</td></tr>';
                    
                    echo '</table>';*/
                }else{
                    //echo "Error no se ha encontrado ese profesor";
                }
            }
        }else{
            header('location:../../wordpress');
        }
    }
}