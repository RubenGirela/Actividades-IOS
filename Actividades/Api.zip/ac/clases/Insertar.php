<?php

class Insertar{
    
    function addNew($rest,$gestor,$objeto){
        
        if($rest=='profesor'){
                        
            //JSON
            /*
                {
                    "nombre" : "pepe", 
                    "departamento" : "titulo1"
                }
            */
        
            //NO DESCOMENTARLO
           /* foreach ($objeto as $ob){
                echo '<h2>'.$ob.'</h2>';
            }*/
            
            if($objeto->nombre!='' && $objeto->departamento!=''){
                
                $profesorBuscado = $gestor->getRepository('Profesor')->findOneBy(array('nombre' => $objeto->nombre));
            
                if($profesorBuscado === null){
                    
                    $profesor = new Profesor();
                    
                    $profesor->setNombre($objeto->nombre);
                    $profesor->setDepartamento($objeto->departamento);
        
                    $gestor->persist($profesor);
                    $gestor->flush();
                    
                    //echo '<h5>Profesor Insertado correctamente</h5>';
                } else {
                    
                    print_r('Error el profesor existe');
                }
            }else{
                
                print_r('Error Profesor mal insertado, consulte con nuestro tecnico');
            }
            
        }elseif($rest=='actividad'){
            
             //JSON
            /*
                {
                    "profesor" : 1, 
                    "titulo" : "titulo1", 
                    "descripcion_corta" : "descripción corta 1", 
                    "descripcion_larga" : "descripción larga 1", 
                    "grupo" : "grupo1", 
                    "fecha" : "12-03-2016", 
                    "lugar" : "lugar1", 
                    "hora_inicial" : "12:00", 
                    "hora_final" : "13:00"
                    
                }
            */
            
            if($objeto->titulo!='' && $objeto->profesor!='' && $objeto->grupo!='' && $objeto->fecha!='' && $objeto->lugar!='' && $objeto->hora_inicial!='' && $objeto->hora_final!=''){
                
                $actividadBuscado = $gestor->getRepository('Actividad')->findOneBy(array('titulo' => $objeto->titulo, 'fecha' => $date, 'lugar' => $objeto->lugar));

                if($actividadBuscado === null){
                    
                    $actividad = new Actividad();
                    $profesor = $gestor->getRepository('Profesor')->findOneBy(array('id' => $objeto->profesor));
                    $date = new DateTime($objeto->fecha);
                    $timeInicial= new DateTime($objeto->hora_inicial);
                    $timeFinal= new DateTime($objeto->hora_final);
                    
                    $actividad->setProfesor($profesor);
                    $actividad->setTitulo($objeto->titulo);
                    $actividad->setDescripcionCorta($objeto->descripcion_corta);
                    $actividad->setDescripcionLarga($objeto->descripcion_larga);
                    $actividad->setGrupo($objeto->grupo);
                    $actividad->setFecha($date);
                    $actividad->setLugar($objeto->lugar);
                    $actividad->setHoraInicial($timeInicial);
                    $actividad->setHoraFinal($timeFinal);
                    
                    //Comprobamos la imagen
                    //La imagen tiene los valores data:image....
                    //echo "Enlace: ".$_SERVER['REQUEST_SCHEME'];
                    if (!empty($objeto->imagen)) {
                      //$patternimg = '/\.(jpe?g|png|gif|bmp)$/';
                      if ( base64_encode(base64_decode($objeto->imagen, true)) === $objeto->imagen) {
                        $data = base64_decode($objeto->imagen);
                        $archivo = md5("actividad_".time()).'.png';
                        file_put_contents('../ImagesExcursions'.$archivo, $data);
                        $scheme = $_SERVER['REQUEST_SCHEME'];
                        $domain = $_SERVER['SERVER_NAME'];
                        //file_put_contents('../wordpress/wp-content/themes/actividadesZaidinVergeles/assets/img/excursiones'.$archivo, $data);
                        //$actividad->setFoto('assets/img/excrusiones/ImagesExcursions/'.$archivo);
                        $actividad->setFoto($scheme.'://'.$domain.'/ImagesExcursions/'.$archivo);
                        //$this->imagen = $archivo;
                      } /*elseif ( preg_match( $patternimg, $objeto->imagen) ) {
                        $this->imagen = $objeto->imagen;
                      }*/
                    }
                        
                    //$actividad->setFoto($file);
        
                    $gestor->persist($actividad);
                    $gestor->flush();
                    
                    //echo '<h5>Acrtividad Insertada correctamente</h5>';
                } else {
                    
                    print_r('Error la actividad existe');
                }
            }else{
                
                print('Error Actividad mal insertada, consulte con nuestro tecnico');
            }
        }
    }
}