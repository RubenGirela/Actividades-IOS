<?php

class Api{
    private $gestor;
    private $metodo, $json, $pRest, $pGet;
    private $respuesta;
    
    function __construct($metodo,$json,$parametrosRest, $parametrosGet){
        $this->metodo=$metodo;
        $this->json=$json;
        $this->pRest=$parametrosRest;
        $this->pGet=$parametrosGet;
        
        $bootstrap = new Bootstrap();
        $this->gestor = $bootstrap->getEntityManager();
    }
    
    function peticiones(){
        
        if(isset($this->metodo)){
            $rest=$this->pRest[2];
            $rest2=$this->pRest[3];
            $gestor=$this->gestor;
            $objeto = $this->json;
            
            switch ($this->metodo) {
                case 'GET':
                    //echo '<h3>GET</h3>';
                    
                    $ver = new Mostrar();
                    
                    $ver->see($rest, $gestor,$rest2);
                    break;
                case 'POST':
                    //echo '<h3>POST</h3>';
                    
                    $insertar = new Insertar();
                    
                    $insertar->addNew($rest,$gestor,$objeto);
                    
                    //NO LA VOY A USAR
                   /* try {// insertar profesor
                        $actividades = new profesor();
                        $actividades->setNombre('nombre3');
                        $actividades->setDepartamento('departamento');
                        $gestor->persist($actividades);// insercion
                        echo '<h1>'.$actividades->getId() . '</h1><br>';
                        $gestor->flush();// comint
                        echo $actividades->getId();
                    }catch(Exception $e){
                        echo "<h1>Error </h1>";
                    }*/
                    
                    break;
                case 'PUT':
                    //echo '<h3>PUT</h3>';
                    
                    $mod = new Modificar();
                    
                    $mod->mod($rest,$gestor,$objeto);
                     
                    break;
                case 'DELETE':
                    //echo '<h3>DELETE</h3>';
                    
                    $del = new Borrar();
                    
                    $del->borrado($rest,$gestor,$objeto);
                    
                    break;
                default:
                    print_r('Error 404 no se ha encontrado NADA pongase en contacto con el desarrollador');
                    break;
            }
        }
        
/*******************************************************************************************************************************************************************************************************************/
        
        /*$tabla = $this->pRest[2];
        $clase = 'Controlador'.ucfirst($tabla);
        $json=$this->json;
        $objeto = new $clase($json, $this->pRest, $this->pGet);
        $metodo = $this->metodo;
        
        $this->respuesta = $objeto->$metodo();*/
        /*if(isset($this->pRest[0])){
            
            $this->respuesta = $this->pRest[2];
            
            if($this->respuesta === 'insert'){
                $p = new profesor();
                $p->setNombre($this->pRest[3]);
                $this->gestor->persist($p);
                $this->gestor->flush();
                
                $array =array('id' => $p->getId());
                $this->respuesta = json_encode($array);
            }elseif($this->respuesta === 'ver'){
                
                $p1 = new profesor();
                $p1->setId(1)->setNombre('pepe');
                $p2 = new profesor();
                $p2->setId(2)->setNombre('paco');
                $array = array();
                $array[] = $p1->toArray();
                $array[] = $p2->toArray();
                $this->respuesta = json_encode($array);
            }else{
                $this->respuesta = 'Sin peticiones';
            }
        }else{
            $this->respuesta = 'Sin peticiones';
        }*/
    }
    
/*******************************************************************************************************************************************************************************************************************/

    function getResponse(){
        return $this->respuesta;
    }
}