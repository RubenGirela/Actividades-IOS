<?php

/**
 * @Entity 
 * @Table(name="Actividad")
 */
class Actividad {
    
    /**
     * @Id
     * @Column(type="integer") @GeneratedValue
     * uniqueConstraints={@UniqueConstraint(name="ap_unique",columns={"idprofesor","Actividad"})})
     */
    protected $id;
    
    /**
     * @ManyToOne(targetEntity="Profesor", inversedBy="actividades")
     * @JoinColumn(name="idprofesor", referencedColumnName="id", onDelete="CASCADE")
     */
    protected $id_profesor;
    
    /**
     * @Column(type="string", length=200, unique=false, nullable=true)
     */
    protected $descripcion_larga;
    
    /**
     * @Column(type="string", length=50, unique=false, nullable=true)
     */
    protected $descripcion_corta;
    
    /**
     * @Column(type="string", length=50, unique=false, nullable=true)
     */
    protected $titulo;
    
    /**
     * @Column(type="string", length=50, unique=false, nullable=true)
     */
    protected $grupo;
    
    /**
     * @Column(type="date", unique=false, nullable=true)
     */
    protected $fecha;
    
    /**
     * @Column(type="string", length=100, unique=false, nullable=true)
     */
    protected $lugar;
    
    /**
     * @Column(type="time", unique=false, nullable=true)
     */
    protected $hora_inicial;
    
    /**
     * @Column(type="time", unique=false, nullable=true)
     */
    protected $hora_final;
    
    /**
     * @Column(type="string", length=200, unique=false, nullable=true)
     */
    protected $foto;

    public function getId() {
        return $this->id;
    }

    public function getProfesor() {
        return $this->id_profesor;
    }

    public function getDescripcionLarga() {
        return $this->descripcion_larga;
    }
    
    public function getDescripcionCorta() {
        return $this->descripcion_corta;
    }
    
    public function getTitulo() {
        return $this->titulo;
    }
    public function getGrupo() {
        return $this->grupo;
    }
    
    public function getFecha() {
        return $this->fecha;
    }
    
    public function getLugar() {
        return $this->lugar;
    }
    
    public function getHorainicial() {
        return $this->hora_inicial;
    }
    
    public function getHorafinal() {
        return $this->hora_final;
    }
    
    public function getFoto() {
        return $this->foto;
    }

    public function setId($id) {
        $this->id = $id;
        return $this;
    }

    public function setProfesor($id_profesor) {
        $id_profesor->addActividad($this);
        $this->id_profesor = $id_profesor;
    }

    public function setDescripcionLarga($descripcion_larga) {
        $this->descripcion_larga = $descripcion_larga;
        return $this;
    }
    
    public function setDescripcionCorta($descripcion_corta) {
        $this->descripcion_corta = $descripcion_corta;
        return $this;
    }
    
    public function setTitulo($titulo) {
        $this->titulo = $titulo;
        return $this;
    }
    
    public function setGrupo($grupo) {
        $this->grupo = $grupo;
        return $this;
    }
    
    public function setFecha($fecha) {
        $this->fecha = $fecha;
        return $this;
    }
    
    public function setLugar($lugar) {
        $this->lugar = $lugar;
        return $this;
    }
    
    public function setHoraInicial($hora_inicial) {
        $this->hora_inicial = $hora_inicial;
        return $this;
    }
    
    public function setHoraFinal($hora_final) {
        $this->hora_final = $hora_final;
        return $this;
    }
    
    public function setFoto($foto) {
        $this->foto = $foto;
        return $this;
    }
}