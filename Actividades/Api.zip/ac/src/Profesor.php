<?php

use Doctrine\Common\Collections\ArrayCollection;

/**
 * @Entity 
 * @Table(name="Profesor")
 */
class Profesor {
    
    /**
     * @Id
     * @Column(type="integer") @GeneratedValue
     */
    protected $id;
    
    /**
     * @Column(type="string", length=200, unique=true, nullable=false)
     */
    protected $nombre;
    
    /**
     * @Column(type="string", length=100, unique=false, nullable=true)
     */
    protected $departamento;
    
     /**
     * @OneToMany(targetEntity="Actividad", mappedBy="id_profesor")
     */
    protected $actividades = null;
    
    public function __construct() {
        $this->actividades = new ArrayCollection();
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getDepartamento() {
        return $this->departamento;
    }

    public function setId($id) {
        $this->id = $id;
        return $this;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
        return $this;
    }

    public function setDepartamento($departamento) {
        $this->departamento = $departamento;
        return $this;
    }
    
    public function addActividad($actividad){
        $this->actividades[] = $actividad;
    }
    
    public function getActividades(){
        return $this->actividades;
    }
    
    function toArray(){
        $array = array (
            'id' => $this->getId(),
            'nombre' => $this->getNombre()
        );
        return $array;
    }
}